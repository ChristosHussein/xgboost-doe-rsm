| Source of Variation | DF | Sum of Squares | Mean Square | F-Statistic | p-Value |
| :--- | :--- | :--- | :--- | :--- | :--- |
| Model | 18 | 14359.542407 | 797.752356 | 99.67 | 1.2826e-63 |
|   Main Effects | 4 | 13911.816495 | 3477.954124 | 434.55 | 9.4286e-71 |
|   2-Factor Interactions | 6 | 346.470219 | 57.745037 | 7.21 | 1.3453e-06 |
|   Curvature (Quadratic) | 4 | 7.183998 | 1.796000 | 0.22 | 9.2433e-01 |
|   Blocks | 4 | 76.754036 | 19.188509 | 2.40 | 5.3926e-02 |
| Residual | 121 | 968.433593 | 8.003583 | - | - |
|   Lack of Fit | 116 | 961.374843 | 8.287714 | 5.87 | 2.6917e-02 |
|   Pure Error | 5 | 7.058750 | 1.411750 | - | - |
| Total | 139 | 15327.976000 | 110.273209 | - | - |

**Model Fit:** $R^2 = 0.9368$, Adjusted $R^2 = 0.9274$
Group effects are partial sums of squares, not generally an additive SS partition. Undefined F/LoF tests indicate insufficient estimated error variance.
**Lack of Fit Test:** $F = 5.87$ ($p = 2.6917e-02$)