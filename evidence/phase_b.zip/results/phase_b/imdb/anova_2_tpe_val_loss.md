| Source of Variation | DF | Sum of Squares | Mean Square | F-Statistic | p-Value |
| :--- | :--- | :--- | :--- | :--- | :--- |
| Model | 18 | 0.001590 | 0.000088 | 18.03 | 3.6586e-26 |
|   Main Effects | 4 | 0.000160 | 0.000040 | 8.14 | 7.5741e-06 |
|   2-Factor Interactions | 6 | 0.000085 | 0.000014 | 2.88 | 1.1767e-02 |
|   Curvature (Quadratic) | 4 | 0.000131 | 0.000033 | 6.70 | 6.5951e-05 |
|   Blocks | 4 | 0.000787 | 0.000197 | 40.16 | 2.2603e-21 |
| Residual | 121 | 0.000593 | 0.000005 | - | - |
| Total | 139 | 0.002183 | 0.000016 | - | - |

**Model Fit:** $R^2 = 0.7285$, Adjusted $R^2 = 0.6881$
Group effects are partial sums of squares, not generally an additive SS partition. Undefined F/LoF tests indicate insufficient estimated error variance.