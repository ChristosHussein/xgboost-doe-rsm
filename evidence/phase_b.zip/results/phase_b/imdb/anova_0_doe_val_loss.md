| Source of Variation | DF | Sum of Squares | Mean Square | F-Statistic | p-Value |
| :--- | :--- | :--- | :--- | :--- | :--- |
| Model | 18 | 0.011669 | 0.000648 | 60.38 | 1.2096e-51 |
|   Main Effects | 4 | 0.002975 | 0.000744 | 69.26 | 2.2279e-30 |
|   2-Factor Interactions | 6 | 0.003920 | 0.000653 | 60.85 | 3.1782e-34 |
|   Curvature (Quadratic) | 4 | 0.003694 | 0.000923 | 86.00 | 1.9369e-34 |
|   Blocks | 4 | 0.000814 | 0.000204 | 18.96 | 3.9877e-12 |
| Residual | 121 | 0.001299 | 0.000011 | - | - |
|   Lack of Fit | 116 | 0.001276 | 0.000011 | 2.38 | 1.6567e-01 |
|   Pure Error | 5 | 0.000023 | 0.000005 | - | - |
| Total | 139 | 0.012969 | 0.000093 | - | - |

**Model Fit:** $R^2 = 0.8998$, Adjusted $R^2 = 0.8849$
Group effects are partial sums of squares, not generally an additive SS partition. Undefined F/LoF tests indicate insufficient estimated error variance.
**Lack of Fit Test:** $F = 2.38$ ($p = 1.6567e-01$)