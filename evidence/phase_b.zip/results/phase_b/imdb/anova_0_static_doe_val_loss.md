| Source of Variation | DF | Sum of Squares | Mean Square | F-Statistic | p-Value |
| :--- | :--- | :--- | :--- | :--- | :--- |
| Model | 18 | 0.012073 | 0.000671 | 64.44 | 3.6385e-53 |
|   Main Effects | 4 | 0.002957 | 0.000739 | 71.01 | 7.7989e-31 |
|   2-Factor Interactions | 6 | 0.003898 | 0.000650 | 62.42 | 1.0049e-34 |
|   Curvature (Quadratic) | 4 | 0.004400 | 0.001100 | 105.69 | 1.5767e-38 |
|   Blocks | 4 | 0.000818 | 0.000204 | 19.64 | 1.7808e-12 |
| Residual | 121 | 0.001259 | 0.000010 | - | - |
|   Lack of Fit | 106 | 0.001186 | 0.000011 | 2.29 | 3.5171e-02 |
|   Pure Error | 15 | 0.000073 | 0.000005 | - | - |
| Total | 139 | 0.013333 | 0.000096 | - | - |

**Model Fit:** $R^2 = 0.9055$, Adjusted $R^2 = 0.8915$
Group effects are partial sums of squares, not generally an additive SS partition. Undefined F/LoF tests indicate insufficient estimated error variance.
**Lack of Fit Test:** $F = 2.29$ ($p = 3.5171e-02$)