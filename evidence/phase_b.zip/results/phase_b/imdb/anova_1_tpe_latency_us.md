| Source of Variation | DF | Sum of Squares | Mean Square | F-Statistic | p-Value |
| :--- | :--- | :--- | :--- | :--- | :--- |
| Model | 18 | 36834.400596 | 2046.355589 | 9.89 | 2.3179e-16 |
|   Main Effects | 4 | 13630.231154 | 3407.557788 | 16.47 | 8.5200e-11 |
|   2-Factor Interactions | 6 | 4011.684044 | 668.614007 | 3.23 | 5.5880e-03 |
|   Curvature (Quadratic) | 4 | 4689.437671 | 1172.359418 | 5.66 | 3.2568e-04 |
|   Blocks | 4 | 776.217036 | 194.054259 | 0.94 | 4.4464e-01 |
| Residual | 121 | 25041.593761 | 206.955320 | - | - |
| Total | 139 | 61875.994357 | 445.151039 | - | - |

**Model Fit:** $R^2 = 0.5953$, Adjusted $R^2 = 0.5351$
Group effects are partial sums of squares, not generally an additive SS partition. Undefined F/LoF tests indicate insufficient estimated error variance.