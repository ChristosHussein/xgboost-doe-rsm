| Source of Variation | DF | Sum of Squares | Mean Square | F-Statistic | p-Value |
| :--- | :--- | :--- | :--- | :--- | :--- |
| Model | 18 | 0.012271 | 0.000682 | 93.22 | 5.4481e-62 |
|   Main Effects | 4 | 0.003423 | 0.000856 | 117.04 | 1.2614e-40 |
|   2-Factor Interactions | 6 | 0.003528 | 0.000588 | 80.41 | 7.4612e-40 |
|   Curvature (Quadratic) | 4 | 0.004635 | 0.001159 | 158.46 | 4.1018e-47 |
|   Blocks | 4 | 0.000685 | 0.000171 | 23.41 | 2.3958e-14 |
| Residual | 121 | 0.000885 | 0.000007 | - | - |
|   Lack of Fit | 106 | 0.000778 | 0.000007 | 1.03 | 5.1085e-01 |
|   Pure Error | 15 | 0.000107 | 0.000007 | - | - |
| Total | 139 | 0.013156 | 0.000095 | - | - |

**Model Fit:** $R^2 = 0.9327$, Adjusted $R^2 = 0.9227$
Group effects are partial sums of squares, not generally an additive SS partition. Undefined F/LoF tests indicate insufficient estimated error variance.
**Lack of Fit Test:** $F = 1.03$ ($p = 5.1085e-01$)