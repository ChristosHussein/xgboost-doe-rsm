| Source of Variation | DF | Sum of Squares | Mean Square | F-Statistic | p-Value |
| :--- | :--- | :--- | :--- | :--- | :--- |
| Model | 18 | 0.011188 | 0.000622 | 87.75 | 1.5923e-60 |
|   Main Effects | 4 | 0.002844 | 0.000711 | 100.39 | 1.7314e-37 |
|   2-Factor Interactions | 6 | 0.003820 | 0.000637 | 89.88 | 3.3657e-42 |
|   Curvature (Quadratic) | 4 | 0.004045 | 0.001011 | 142.75 | 7.7483e-45 |
|   Blocks | 4 | 0.000480 | 0.000120 | 16.93 | 4.7765e-11 |
| Residual | 121 | 0.000857 | 0.000007 | - | - |
|   Lack of Fit | 106 | 0.000726 | 0.000007 | 0.78 | 7.7074e-01 |
|   Pure Error | 15 | 0.000131 | 0.000009 | - | - |
| Total | 139 | 0.012045 | 0.000087 | - | - |

**Model Fit:** $R^2 = 0.9288$, Adjusted $R^2 = 0.9183$
Group effects are partial sums of squares, not generally an additive SS partition. Undefined F/LoF tests indicate insufficient estimated error variance.
**Lack of Fit Test:** $F = 0.78$ ($p = 7.7074e-01$)