| Source of Variation | DF | Sum of Squares | Mean Square | F-Statistic | p-Value |
| :--- | :--- | :--- | :--- | :--- | :--- |
| Model | 18 | 13935.985743 | 774.221430 | 24.39 | 6.4054e-32 |
|   Main Effects | 4 | 13144.261972 | 3286.065493 | 103.53 | 4.1450e-38 |
|   2-Factor Interactions | 6 | 132.014187 | 22.002365 | 0.69 | 6.5555e-01 |
|   Curvature (Quadratic) | 4 | 224.713405 | 56.178351 | 1.77 | 1.3928e-01 |
|   Blocks | 4 | 434.996179 | 108.749045 | 3.43 | 1.0852e-02 |
| Residual | 121 | 3840.699185 | 31.741316 | - | - |
|   Lack of Fit | 106 | 3677.347935 | 34.691962 | 3.19 | 6.9436e-03 |
|   Pure Error | 15 | 163.351250 | 10.890083 | - | - |
| Total | 139 | 17776.684929 | 127.889820 | - | - |

**Model Fit:** $R^2 = 0.7839$, Adjusted $R^2 = 0.7518$
Group effects are partial sums of squares, not generally an additive SS partition. Undefined F/LoF tests indicate insufficient estimated error variance.
**Lack of Fit Test:** $F = 3.19$ ($p = 6.9436e-03$)