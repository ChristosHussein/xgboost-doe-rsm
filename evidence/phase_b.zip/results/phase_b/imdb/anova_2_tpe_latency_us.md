| Source of Variation | DF | Sum of Squares | Mean Square | F-Statistic | p-Value |
| :--- | :--- | :--- | :--- | :--- | :--- |
| Model | 18 | 17685.531560 | 982.529531 | 5.02 | 2.3566e-08 |
|   Main Effects | 4 | 10071.583580 | 2517.895895 | 12.86 | 9.3780e-09 |
|   2-Factor Interactions | 6 | 3631.824939 | 605.304157 | 3.09 | 7.4982e-03 |
|   Curvature (Quadratic) | 4 | 2193.532044 | 548.383011 | 2.80 | 2.8886e-02 |
|   Blocks | 4 | 133.316321 | 33.329080 | 0.17 | 9.5322e-01 |
| Residual | 121 | 23692.049494 | 195.802062 | - | - |
| Total | 139 | 41377.581054 | 297.680439 | - | - |

**Model Fit:** $R^2 = 0.4274$, Adjusted $R^2 = 0.3422$
Group effects are partial sums of squares, not generally an additive SS partition. Undefined F/LoF tests indicate insufficient estimated error variance.