| Source of Variation | DF | Sum of Squares | Mean Square | F-Statistic | p-Value |
| :--- | :--- | :--- | :--- | :--- | :--- |
| Model | 18 | 8202.740011 | 455.707778 | 215.42 | 7.6545e-83 |
|   Main Effects | 4 | 3844.834943 | 961.208736 | 454.38 | 7.5504e-72 |
|   2-Factor Interactions | 6 | 36.618619 | 6.103103 | 2.89 | 1.1570e-02 |
|   Curvature (Quadratic) | 4 | 23.382648 | 5.845662 | 2.76 | 3.0615e-02 |
|   Blocks | 4 | 25.947036 | 6.486759 | 3.07 | 1.9078e-02 |
| Residual | 121 | 255.967471 | 2.115434 | - | - |
| Total | 139 | 8458.707482 | 60.854011 | - | - |

**Model Fit:** $R^2 = 0.9697$, Adjusted $R^2 = 0.9652$
Group effects are partial sums of squares, not generally an additive SS partition. Undefined F/LoF tests indicate insufficient estimated error variance.