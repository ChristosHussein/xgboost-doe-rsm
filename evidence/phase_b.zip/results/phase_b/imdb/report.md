# Explainable sequential DOE study

Evidence classification: **research**.
Synthetic/smoke results validate execution only; they support no real-data scientific conclusion.

| Method | Search fits | Mean validation hypervolume | SD across searches |
| --- | ---: | ---: | ---: |
| static_doe | 420 | 162.809153 | 2.761313 |
| doe | 420 | 162.277851 | 2.335793 |
| tpe | 420 | 161.806581 | 3.095528 |

Confirmation fits: 540; final fits: 9; total: 1809.
Final protected evaluation: **COMPLETED**.

| Method/response | Independent-point observations | Prediction RMSE | Observed - predicted bias | Fixed-block PI coverage |
| --- | ---: | ---: | ---: | ---: |
| static_doe:val_loss | 180 | 0.003429 | -0.000458 | 0.9333 |
| static_doe:latency_us | 180 | 5.628042 | -0.751884 | 0.9833 |
| doe:val_loss | 180 | 0.003346 | -0.000144 | 0.9333 |
| doe:latency_us | 180 | 4.779335 | -0.532486 | 0.9778 |
| tpe:val_loss | 180 | 0.006434 | 0.001329 | 0.8111 |
| tpe:latency_us | 180 | 22.635152 | -3.254192 | 0.8889 |

## Flexible-surrogate confirmation

| Method/response | Reserved configurations | GP prediction RMSE | GP model-based interval coverage |
| --- | ---: | ---: | ---: |
| static_doe:val_loss | 36 | 0.002482 | 0.8056 |
| static_doe:latency_us | 36 | 5.661179 | 0.8333 |
| doe:val_loss | 36 | 0.002458 | 0.8611 |
| doe:latency_us | 36 | 3.267978 | 0.9444 |
| tpe:val_loss | 36 | 0.006883 | 0.7500 |
| tpe:latency_us | 36 | 10.897292 | 0.7778 |

## Frozen-selection final test evaluation

| Method | Search replicate | Test macro F1 | Test log loss | Classic latency (us/document) |
| --- | ---: | ---: | ---: | ---: |
| static_doe | 0 | 0.878434 | 0.286154 | 173.650000 |
| tpe | 0 | 0.879321 | 0.287229 | 174.550000 |
| doe | 0 | 0.879681 | 0.285474 | 176.050000 |
| tpe | 1 | 0.876665 | 0.288161 | 173.500000 |
| static_doe | 1 | 0.877384 | 0.289200 | 174.200000 |
| doe | 1 | 0.878434 | 0.286154 | 177.350000 |
| static_doe | 2 | 0.879471 | 0.288459 | 176.050000 |
| tpe | 2 | 0.879294 | 0.283810 | 173.300000 |
| doe | 2 | 0.878434 | 0.286154 | 174.950000 |

## Explanation agreement before and after augmentation

| Search/response | Initial Spearman rho | Final Spearman rho | Initial interaction correlation | Final interaction correlation |
| --- | ---: | ---: | ---: | ---: |
| 0:val_loss | 1.0000 | 1.0000 | 0.9983 | 0.9981 |
| 1:val_loss | 1.0000 | 0.4000 | 0.9778 | 0.9259 |
| 2:val_loss | 0.4000 | 0.4000 | 0.9985 | 0.9989 |
| 0:latency_us | 1.0000 | 1.0000 | 0.9702 | 0.9833 |
| 1:latency_us | 1.0000 | 1.0000 | 0.9201 | 0.9054 |
| 2:latency_us | 0.4000 | 0.8000 | -0.0113 | 0.9812 |

## Interpretation and limits

Responses are validation 1 - macro F1 and uncached classic-API latency in microseconds per document. The classic operation includes fresh DMatrix construction; inplace timing excludes this conversion. Hypervolumes and feasible fractions use means across the same development blocks. The regret comparator is the best observed loss among these methods, not the unknown true optimum.

ANOVA partial sums of squares and interventional Shapley values are different estimands. Snapshots compare RSM and GP on the same empirical background and reserved coordinates. Curvature profiles record SHAP main-effect dependence at three anchors; they are not significance tests. Undefined correlations remain undefined. Coverage is descriptive for observations at new coordinates within the observed fixed blocks; it does not validate unseen-block generalization. Repeated fold observations are dependent, so no independent-sample inference is claimed.

All numerical claims above are reconstructed from `evaluations.jsonl`, `confirmation.json`, the frozen measurement contract, and per-method overhead observations. The registry includes every run file; `--check` rejects missing, additional, modified, or stale-source artifacts.

## Scientific graphics

![Validation Pareto evidence, SHAP interactions, curvature and fit efficiency](study_figures.png)
