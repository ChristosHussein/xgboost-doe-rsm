| Source of Variation | DF | Sum of Squares | Mean Square | F-Statistic | p-Value |
| :--- | :--- | :--- | :--- | :--- | :--- |
| Model | 18 | 22408.604550 | 1244.922475 | 19.47 | 1.4140e-27 |
|   Main Effects | 4 | 18870.364528 | 4717.591132 | 73.78 | 1.5433e-31 |
|   2-Factor Interactions | 6 | 2840.349250 | 473.391542 | 7.40 | 9.2028e-07 |
|   Curvature (Quadratic) | 4 | 276.478201 | 69.119550 | 1.08 | 3.6902e-01 |
|   Blocks | 4 | 421.412571 | 105.353143 | 1.65 | 1.6670e-01 |
| Residual | 121 | 7736.954450 | 63.941772 | - | - |
|   Lack of Fit | 106 | 7700.773825 | 72.648810 | 30.12 | 2.5551e-09 |
|   Pure Error | 15 | 36.180625 | 2.412042 | - | - |
| Total | 139 | 30145.559000 | 216.874525 | - | - |

**Model Fit:** $R^2 = 0.7433$, Adjusted $R^2 = 0.7052$
Group effects are partial sums of squares, not generally an additive SS partition. Undefined F/LoF tests indicate insufficient estimated error variance.
**Lack of Fit Test:** $F = 30.12$ ($p = 2.5551e-09$)