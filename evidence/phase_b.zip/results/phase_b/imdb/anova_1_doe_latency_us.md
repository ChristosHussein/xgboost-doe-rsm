| Source of Variation | DF | Sum of Squares | Mean Square | F-Statistic | p-Value |
| :--- | :--- | :--- | :--- | :--- | :--- |
| Model | 18 | 22163.802872 | 1231.322382 | 30.87 | 9.8802e-37 |
|   Main Effects | 4 | 20463.121480 | 5115.780370 | 128.26 | 1.5130e-42 |
|   2-Factor Interactions | 6 | 1489.412442 | 248.235407 | 6.22 | 1.0181e-05 |
|   Curvature (Quadratic) | 4 | 43.432587 | 10.858147 | 0.27 | 8.9539e-01 |
|   Blocks | 4 | 70.631429 | 17.657857 | 0.44 | 7.7753e-01 |
| Residual | 121 | 4826.392842 | 39.887544 | - | - |
|   Lack of Fit | 116 | 4708.644092 | 40.591759 | 1.72 | 2.8490e-01 |
|   Pure Error | 5 | 117.748750 | 23.549750 | - | - |
| Total | 139 | 26990.195714 | 194.174070 | - | - |

**Model Fit:** $R^2 = 0.8212$, Adjusted $R^2 = 0.7946$
Group effects are partial sums of squares, not generally an additive SS partition. Undefined F/LoF tests indicate insufficient estimated error variance.
**Lack of Fit Test:** $F = 1.72$ ($p = 2.8490e-01$)