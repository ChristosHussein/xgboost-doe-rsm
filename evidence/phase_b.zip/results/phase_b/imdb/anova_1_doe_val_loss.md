| Source of Variation | DF | Sum of Squares | Mean Square | F-Statistic | p-Value |
| :--- | :--- | :--- | :--- | :--- | :--- |
| Model | 18 | 0.010786 | 0.000599 | 78.11 | 9.9723e-58 |
|   Main Effects | 4 | 0.002697 | 0.000674 | 87.88 | 7.3861e-35 |
|   2-Factor Interactions | 6 | 0.003773 | 0.000629 | 81.97 | 2.9548e-40 |
|   Curvature (Quadratic) | 4 | 0.003545 | 0.000886 | 115.52 | 2.3552e-40 |
|   Blocks | 4 | 0.000499 | 0.000125 | 16.25 | 1.1160e-10 |
| Residual | 121 | 0.000928 | 0.000008 | - | - |
|   Lack of Fit | 116 | 0.000901 | 0.000008 | 1.45 | 3.6610e-01 |
|   Pure Error | 5 | 0.000027 | 0.000005 | - | - |
| Total | 139 | 0.011714 | 0.000084 | - | - |

**Model Fit:** $R^2 = 0.9208$, Adjusted $R^2 = 0.9090$
Group effects are partial sums of squares, not generally an additive SS partition. Undefined F/LoF tests indicate insufficient estimated error variance.
**Lack of Fit Test:** $F = 1.45$ ($p = 3.6610e-01$)