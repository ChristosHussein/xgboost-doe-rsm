| Source of Variation | DF | Sum of Squares | Mean Square | F-Statistic | p-Value |
| :--- | :--- | :--- | :--- | :--- | :--- |
| Model | 18 | 0.011940 | 0.000663 | 78.26 | 9.0005e-58 |
|   Main Effects | 4 | 0.003872 | 0.000968 | 114.20 | 4.0736e-40 |
|   2-Factor Interactions | 6 | 0.003556 | 0.000593 | 69.92 | 5.5042e-37 |
|   Curvature (Quadratic) | 4 | 0.003889 | 0.000972 | 114.72 | 3.2846e-40 |
|   Blocks | 4 | 0.000723 | 0.000181 | 21.33 | 2.4664e-13 |
| Residual | 121 | 0.001026 | 0.000008 | - | - |
|   Lack of Fit | 116 | 0.000968 | 0.000008 | 0.72 | 7.6698e-01 |
|   Pure Error | 5 | 0.000058 | 0.000012 | - | - |
| Total | 139 | 0.012966 | 0.000093 | - | - |

**Model Fit:** $R^2 = 0.9209$, Adjusted $R^2 = 0.9091$
Group effects are partial sums of squares, not generally an additive SS partition. Undefined F/LoF tests indicate insufficient estimated error variance.
**Lack of Fit Test:** $F = 0.72$ ($p = 7.6698e-01$)