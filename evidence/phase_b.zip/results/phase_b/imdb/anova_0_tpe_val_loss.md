| Source of Variation | DF | Sum of Squares | Mean Square | F-Statistic | p-Value |
| :--- | :--- | :--- | :--- | :--- | :--- |
| Model | 18 | 0.003938 | 0.000219 | 33.33 | 2.3602e-38 |
|   Main Effects | 4 | 0.000674 | 0.000168 | 25.66 | 2.0914e-15 |
|   2-Factor Interactions | 6 | 0.001023 | 0.000170 | 25.96 | 1.1324e-19 |
|   Curvature (Quadratic) | 4 | 0.000437 | 0.000109 | 16.65 | 6.7639e-11 |
|   Blocks | 4 | 0.000712 | 0.000178 | 27.12 | 4.4987e-16 |
| Residual | 121 | 0.000794 | 0.000007 | - | - |
| Total | 139 | 0.004732 | 0.000034 | - | - |

**Model Fit:** $R^2 = 0.8322$, Adjusted $R^2 = 0.8072$
Group effects are partial sums of squares, not generally an additive SS partition. Undefined F/LoF tests indicate insufficient estimated error variance.