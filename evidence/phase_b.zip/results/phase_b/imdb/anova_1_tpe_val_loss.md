| Source of Variation | DF | Sum of Squares | Mean Square | F-Statistic | p-Value |
| :--- | :--- | :--- | :--- | :--- | :--- |
| Model | 18 | 0.002229 | 0.000124 | 19.44 | 1.4998e-27 |
|   Main Effects | 4 | 0.000505 | 0.000126 | 19.84 | 1.4021e-12 |
|   2-Factor Interactions | 6 | 0.000257 | 0.000043 | 6.73 | 3.6188e-06 |
|   Curvature (Quadratic) | 4 | 0.000181 | 0.000045 | 7.10 | 3.5947e-05 |
|   Blocks | 4 | 0.000887 | 0.000222 | 34.79 | 2.5577e-19 |
| Residual | 121 | 0.000771 | 0.000006 | - | - |
| Total | 139 | 0.003000 | 0.000022 | - | - |

**Model Fit:** $R^2 = 0.7431$, Adjusted $R^2 = 0.7049$
Group effects are partial sums of squares, not generally an additive SS partition. Undefined F/LoF tests indicate insufficient estimated error variance.