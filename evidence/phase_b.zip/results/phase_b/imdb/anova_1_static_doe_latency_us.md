| Source of Variation | DF | Sum of Squares | Mean Square | F-Statistic | p-Value |
| :--- | :--- | :--- | :--- | :--- | :--- |
| Model | 18 | 14340.447837 | 796.691546 | 15.11 | 4.9359e-23 |
|   Main Effects | 4 | 13715.602472 | 3428.900618 | 65.03 | 3.0312e-29 |
|   2-Factor Interactions | 6 | 344.968750 | 57.494792 | 1.09 | 3.7207e-01 |
|   Curvature (Quadratic) | 4 | 133.509365 | 33.377341 | 0.63 | 6.3992e-01 |
|   Blocks | 4 | 146.367250 | 36.591812 | 0.69 | 5.9756e-01 |
| Residual | 121 | 6380.471377 | 52.731168 | - | - |
|   Lack of Fit | 106 | 6328.448252 | 59.702342 | 17.21 | 1.4087e-07 |
|   Pure Error | 15 | 52.023125 | 3.468208 | - | - |
| Total | 139 | 20720.919214 | 149.071361 | - | - |

**Model Fit:** $R^2 = 0.6921$, Adjusted $R^2 = 0.6463$
Group effects are partial sums of squares, not generally an additive SS partition. Undefined F/LoF tests indicate insufficient estimated error variance.
**Lack of Fit Test:** $F = 17.21$ ($p = 1.4087e-07$)