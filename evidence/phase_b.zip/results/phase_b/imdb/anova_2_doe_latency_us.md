| Source of Variation | DF | Sum of Squares | Mean Square | F-Statistic | p-Value |
| :--- | :--- | :--- | :--- | :--- | :--- |
| Model | 18 | 19405.924804 | 1078.106934 | 18.22 | 2.3551e-26 |
|   Main Effects | 4 | 18196.237757 | 4549.059439 | 76.89 | 2.6198e-32 |
|   2-Factor Interactions | 6 | 468.924054 | 78.154009 | 1.32 | 2.5288e-01 |
|   Curvature (Quadratic) | 4 | 386.624158 | 96.656040 | 1.63 | 1.7009e-01 |
|   Blocks | 4 | 106.563107 | 26.640777 | 0.45 | 7.7199e-01 |
| Residual | 121 | 7158.324553 | 59.159707 | - | - |
|   Lack of Fit | 116 | 7078.865803 | 61.024705 | 3.84 | 6.6253e-02 |
|   Pure Error | 5 | 79.458750 | 15.891750 | - | - |
| Total | 139 | 26564.249357 | 191.109708 | - | - |

**Model Fit:** $R^2 = 0.7305$, Adjusted $R^2 = 0.6904$
Group effects are partial sums of squares, not generally an additive SS partition. Undefined F/LoF tests indicate insufficient estimated error variance.
**Lack of Fit Test:** $F = 3.84$ ($p = 6.6253e-02$)